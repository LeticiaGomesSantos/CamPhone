create database CamPhone;
use CamPhone;
create table artigos (id int, nome varchar (100), categoria varchar (100), dataa date, imagem varchar (100));
